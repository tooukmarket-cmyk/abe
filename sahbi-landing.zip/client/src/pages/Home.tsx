/**
 * DESIGN PHILOSOPHY: Ethereal Luminescence
 * - Light as the primary design element - everything emanates soft, ethereal glows
 * - Floating Island Architecture - content on translucent panels that hover
 * - Bioluminescent orbs and light threads representing AI consciousness
 * - Slow, breathing animations (4-6 second cycles)
 */

import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform, useInView } from "framer-motion";
import { 
  Heart, 
  Shield, 
  Brain, 
  Clock, 
  Sparkles, 
  Users, 
  Smartphone,
  MessageCircle,
  Zap,
  Lock
} from "lucide-react";

// Floating Orb Component
const FloatingOrb = ({ 
  size, 
  top, 
  left, 
  delay = 0,
  duration = 6 
}: { 
  size: number; 
  top: string; 
  left: string; 
  delay?: number;
  duration?: number;
}) => (
  <motion.div
    className="orb pointer-events-none"
    style={{ 
      width: size, 
      height: size, 
      top, 
      left,
    }}
    animate={{ 
      y: [0, -30, 0],
      scale: [1, 1.05, 1],
      opacity: [0.6, 0.9, 0.6]
    }}
    transition={{ 
      duration,
      delay,
      repeat: Infinity,
      ease: "easeInOut"
    }}
  />
);

// Section Wrapper with Fade In Animation
const AnimatedSection = ({ 
  children, 
  className = "",
  delay = 0,
  id
}: { 
  children: React.ReactNode; 
  className?: string;
  delay?: number;
  id?: string;
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  
  return (
    <motion.section
      ref={ref}
      id={id}
      className={className}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 60 }}
      transition={{ duration: 0.8, delay, ease: [0.25, 0.1, 0.25, 1] }}
    >
      {children}
    </motion.section>
  );
};

// Feature Card Component
const FeatureCard = ({ 
  icon: Icon, 
  title, 
  delay = 0 
}: { 
  icon: React.ElementType; 
  title: string; 
  delay?: number;
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  
  return (
    <motion.div
      ref={ref}
      className="glass-card rounded-2xl p-6 flex items-center gap-4 glow-sm"
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -4, transition: { duration: 0.3 } }}
    >
      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[oklch(0.85_0.08_230)] to-[oklch(0.75_0.12_250)] flex items-center justify-center">
        <Icon className="w-6 h-6 text-white" />
      </div>
      <span className="font-medium text-[oklch(0.30_0.03_230)]">{title}</span>
    </motion.div>
  );
};

// Why Sahbi Grid Item
const WhyItem = ({ 
  icon: Icon, 
  text, 
  delay = 0 
}: { 
  icon: React.ElementType; 
  text: string; 
  delay?: number;
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  
  return (
    <motion.div
      ref={ref}
      className="flex flex-col items-center text-center p-6"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5, delay }}
    >
      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[oklch(0.92_0.05_230)] to-[oklch(0.88_0.08_250)] flex items-center justify-center mb-4 glow-sm">
        <Icon className="w-8 h-8 text-[oklch(0.50_0.12_230)]" />
      </div>
      <p className="text-[oklch(0.35_0.03_230)] font-medium">{text}</p>
    </motion.div>
  );
};

export default function Home() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);
  
  // Track mouse for parallax effect in hero
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect();
        setMousePosition({
          x: (e.clientX - rect.left - rect.width / 2) / rect.width,
          y: (e.clientY - rect.top - rect.height / 2) / rect.height,
        });
      }
    };
    
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div className="min-h-screen overflow-hidden">
      {/* Navigation */}
      <motion.nav 
        className="fixed top-0 left-0 right-0 z-50 px-6 py-4"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="glass-card px-6 py-3 rounded-full">
            <span className="text-xl font-semibold gradient-text">Sahbi</span>
          </div>
          <div className="glass-card px-4 py-2 rounded-full hidden md:flex items-center gap-6">
            <a href="#about" className="text-sm text-[oklch(0.40_0.03_230)] hover:text-[oklch(0.50_0.12_230)] transition-colors">About</a>
            <a href="#friend" className="text-sm text-[oklch(0.40_0.03_230)] hover:text-[oklch(0.50_0.12_230)] transition-colors">AI Friend</a>
            <a href="#matchmaking" className="text-sm text-[oklch(0.40_0.03_230)] hover:text-[oklch(0.50_0.12_230)] transition-colors">Matchmaking</a>
            <a href="#download" className="btn-ethereal !px-5 !py-2 text-sm">Download</a>
          </div>
        </div>
      </motion.nav>

      {/* SECTION 1: Hero */}
      <motion.section 
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
        style={{ opacity: heroOpacity, scale: heroScale }}
      >
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.97_0.02_230)] via-[oklch(0.99_0.01_230)] to-white" />
        
        {/* Floating Orbs */}
        <FloatingOrb size={80} top="15%" left="10%" delay={0} duration={7} />
        <FloatingOrb size={50} top="25%" left="85%" delay={1} duration={6} />
        <FloatingOrb size={120} top="60%" left="5%" delay={2} duration={8} />
        <FloatingOrb size={60} top="70%" left="90%" delay={0.5} duration={7} />
        <FloatingOrb size={40} top="40%" left="75%" delay={1.5} duration={6} />
        
        {/* Hero Content */}
        <div className="container relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            {/* Text Content */}
            <motion.div 
              className="flex-1 text-center lg:text-left"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.3 }}
            >
              <motion.h1 
                className="mb-6"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              >
                <span className="gradient-text">Sahbi</span>
                <span className="block text-[oklch(0.30_0.03_230)] mt-2">
                  Your AI Friend.
                </span>
                <span className="block text-[oklch(0.30_0.03_230)]">
                  Your Future Connection.
                </span>
              </motion.h1>
              
              <motion.p 
                className="text-xl md:text-2xl text-[oklch(0.45_0.03_230)] mb-10 max-w-xl mx-auto lg:mx-0"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.7 }}
              >
                An AI-powered companion and matchmaking experience designed for real human connection.
              </motion.p>
              
              <motion.div 
                className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.9 }}
              >
                <button className="btn-ethereal flex items-center justify-center gap-3">
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                  </svg>
                  Download on iOS
                </button>
                <button className="btn-ethereal-outline flex items-center justify-center gap-3">
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.53,12.9 20.18,13.18L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z"/>
                  </svg>
                  Download on Android
                </button>
              </motion.div>
            </motion.div>
            
            {/* Hero Image */}
            <motion.div 
              className="flex-1 relative"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              style={{
                transform: `translate(${mousePosition.x * 20}px, ${mousePosition.y * 20}px)`,
              }}
            >
              <div className="relative">
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-[oklch(0.85_0.08_230_/_30%)] to-[oklch(0.80_0.10_260_/_30%)] rounded-[3rem] blur-3xl"
                  animate={{ scale: [1, 1.05, 1], opacity: [0.5, 0.7, 0.5] }}
                  transition={{ duration: 5, repeat: Infinity }}
                />
                <img 
                  src="/images/hero-ai-companion.png" 
                  alt="Sahbi AI Companion"
                  className="relative z-10 w-full max-w-lg mx-auto animate-float"
                />
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <motion.div 
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-[oklch(0.70_0.08_230)] flex items-start justify-center p-2">
            <motion.div 
              className="w-1.5 h-1.5 rounded-full bg-[oklch(0.55_0.12_230)]"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </div>
        </motion.div>
      </motion.section>

      {/* SECTION 2: What is Sahbi */}
      <AnimatedSection id="about" className="py-32 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-white via-[oklch(0.98_0.02_230)] to-white" />
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <motion.div
              className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-8"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
            >
              <Sparkles className="w-4 h-4 text-[oklch(0.55_0.12_230)]" />
              <span className="text-sm text-[oklch(0.45_0.05_230)]">Introducing Sahbi</span>
            </motion.div>
            
            <h2 className="text-[oklch(0.25_0.03_230)] mb-8">
              More Than Dating.<br />
              <span className="gradient-text">More Than AI.</span>
            </h2>
            
            <p className="text-xl text-[oklch(0.45_0.03_230)] leading-relaxed">
              Sahbi is a mobile AI companion designed to support you emotionally, 
              understand you deeply, and help you form meaningful relationships — 
              whether with yourself or with someone special.
            </p>
          </div>
        </div>
      </AnimatedSection>

      {/* SECTION 3: Sahbi Friend */}
      <AnimatedSection id="friend" className="py-32 relative overflow-hidden">
        <FloatingOrb size={100} top="20%" left="0%" delay={0} duration={8} />
        <FloatingOrb size={60} top="60%" left="95%" delay={1} duration={7} />
        
        <div className="container relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            {/* Image */}
            <motion.div 
              className="flex-1 order-2 lg:order-1"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <div className="relative">
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-[oklch(0.88_0.06_230_/_40%)] to-[oklch(0.85_0.08_260_/_40%)] rounded-[3rem] blur-2xl"
                  animate={{ scale: [1, 1.03, 1] }}
                  transition={{ duration: 6, repeat: Infinity }}
                />
                <img 
                  src="/images/ai-friend-avatar.png" 
                  alt="Sahbi AI Friend"
                  className="relative z-10 w-full max-w-md mx-auto animate-breathe"
                />
              </div>
            </motion.div>
            
            {/* Content */}
            <div className="flex-1 order-1 lg:order-2">
              <motion.div
                className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-6"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                <Heart className="w-4 h-4 text-[oklch(0.55_0.12_230)]" />
                <span className="text-sm text-[oklch(0.45_0.05_230)]">AI Companion</span>
              </motion.div>
              
              <h2 className="text-[oklch(0.25_0.03_230)] mb-6">
                <span className="gradient-text">Sahbi Friend</span>
              </h2>
              
              <p className="text-lg text-[oklch(0.45_0.03_230)] mb-10 leading-relaxed">
                An AI friend that listens without judgment, remembers what matters to you, 
                understands your emotions, and grows with your life journey.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                <FeatureCard icon={Brain} title="Emotional intelligence" delay={0} />
                <FeatureCard icon={Clock} title="Always available" delay={0.1} />
                <FeatureCard icon={Sparkles} title="Learns your personality" delay={0.2} />
                <FeatureCard icon={Shield} title="Private & secure" delay={0.3} />
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* SECTION 4: Sahbi Matchmaking */}
      <AnimatedSection id="matchmaking" className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-white via-[oklch(0.97_0.03_230)] to-white" />
        <FloatingOrb size={80} top="10%" left="90%" delay={0.5} duration={7} />
        <FloatingOrb size={50} top="70%" left="5%" delay={1.5} duration={6} />
        
        <div className="container relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            {/* Content */}
            <div className="flex-1">
              <motion.div
                className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-6"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                <Users className="w-4 h-4 text-[oklch(0.55_0.12_230)]" />
                <span className="text-sm text-[oklch(0.45_0.05_230)]">Smart Matching</span>
              </motion.div>
              
              <h2 className="text-[oklch(0.25_0.03_230)] mb-6">
                <span className="gradient-text">Sahbi Matchmaking</span>
              </h2>
              
              <p className="text-lg text-[oklch(0.45_0.03_230)] mb-10 leading-relaxed">
                A new generation of matchmaking powered by AI — focused on compatibility, 
                communication, and long-term connection rather than endless swiping.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                <FeatureCard icon={Brain} title="AI personality matching" delay={0} />
                <FeatureCard icon={MessageCircle} title="Meaningful introductions" delay={0.1} />
                <FeatureCard icon={Zap} title="Less noise, more quality" delay={0.2} />
                <FeatureCard icon={Heart} title="Built for real relationships" delay={0.3} />
              </div>
            </div>
            
            {/* Image */}
            <motion.div 
              className="flex-1"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <div className="relative">
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-[oklch(0.85_0.08_230_/_40%)] to-[oklch(0.82_0.10_260_/_40%)] rounded-[3rem] blur-2xl"
                  animate={{ scale: [1, 1.03, 1] }}
                  transition={{ duration: 6, repeat: Infinity }}
                />
                <img 
                  src="/images/matchmaking-connection.png" 
                  alt="Sahbi Matchmaking"
                  className="relative z-10 w-full max-w-lg mx-auto animate-breathe"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </AnimatedSection>

      {/* SECTION 5: Why Sahbi */}
      <AnimatedSection className="py-32 relative">
        <div className="container relative z-10">
          <div className="text-center mb-16">
            <motion.div
              className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-6"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <Sparkles className="w-4 h-4 text-[oklch(0.55_0.12_230)]" />
              <span className="text-sm text-[oklch(0.45_0.05_230)]">Why Choose Us</span>
            </motion.div>
            
            <h2 className="text-[oklch(0.25_0.03_230)]">
              Why <span className="gradient-text">Sahbi</span>?
            </h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            <WhyItem icon={Heart} text="Built for emotional connection" delay={0} />
            <WhyItem icon={Brain} text="AI that understands humans" delay={0.1} />
            <WhyItem icon={Users} text="Designed for modern relationships" delay={0.2} />
            <WhyItem icon={Smartphone} text="Mobile-first experience" delay={0.3} />
            <WhyItem icon={Lock} text="Safe, respectful, intelligent" delay={0.4} />
          </div>
        </div>
      </AnimatedSection>

      {/* SECTION 6: Mobile App Focus */}
      <AnimatedSection className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-white via-[oklch(0.96_0.03_230)] to-white" />
        <FloatingOrb size={100} top="30%" left="5%" delay={0} duration={8} />
        <FloatingOrb size={70} top="50%" left="90%" delay={1} duration={7} />
        
        <div className="container relative z-10">
          <div className="text-center mb-16">
            <motion.div
              className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-6"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <Smartphone className="w-4 h-4 text-[oklch(0.55_0.12_230)]" />
              <span className="text-sm text-[oklch(0.45_0.05_230)]">Mobile Experience</span>
            </motion.div>
            
            <h2 className="text-[oklch(0.25_0.03_230)] mb-4">
              Designed for <span className="gradient-text">Your Phone</span>
            </h2>
            <p className="text-lg text-[oklch(0.45_0.03_230)] max-w-2xl mx-auto">
              A beautiful, intuitive mobile experience with calm colors and thoughtful design.
            </p>
          </div>
          
          <motion.div 
            className="flex justify-center"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              <motion.div
                className="absolute inset-0 bg-gradient-to-b from-[oklch(0.85_0.08_230_/_50%)] to-[oklch(0.80_0.10_260_/_50%)] rounded-[3rem] blur-3xl scale-90"
                animate={{ scale: [0.9, 0.95, 0.9], opacity: [0.5, 0.7, 0.5] }}
                transition={{ duration: 5, repeat: Infinity }}
              />
              <img 
                src="/images/app-interface-preview.png" 
                alt="Sahbi App Interface"
                className="relative z-10 w-full max-w-xs mx-auto animate-float-slow"
              />
            </div>
          </motion.div>
        </div>
      </AnimatedSection>

      {/* SECTION 7: Call to Action */}
      <AnimatedSection id="download" className="py-32 relative overflow-hidden">
        <FloatingOrb size={120} top="20%" left="5%" delay={0} duration={9} />
        <FloatingOrb size={80} top="60%" left="85%" delay={1} duration={8} />
        <FloatingOrb size={60} top="40%" left="50%" delay={2} duration={7} />
        
        <div className="container relative z-10">
          <div className="glass-card rounded-[3rem] p-12 md:p-20 text-center glow max-w-4xl mx-auto">
            <motion.h2 
              className="text-[oklch(0.25_0.03_230)] mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              Your AI Friend.<br />
              <span className="gradient-text">Your Future Connection.</span>
            </motion.h2>
            
            <motion.p 
              className="text-xl text-[oklch(0.45_0.03_230)] mb-10 max-w-xl mx-auto"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              Experience a new way to connect — with yourself and with others.
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              <button className="btn-ethereal flex items-center justify-center gap-3">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                </svg>
                App Store
              </button>
              <button className="btn-ethereal-outline flex items-center justify-center gap-3">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.53,12.9 20.18,13.18L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z"/>
                </svg>
                Google Play
              </button>
            </motion.div>
          </div>
        </div>
      </AnimatedSection>

      {/* SECTION 8: Footer */}
      <footer className="py-12 border-t border-[oklch(0.90_0.03_230_/_50%)]">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <span className="text-xl font-semibold gradient-text">Sahbi</span>
              <span className="text-[oklch(0.50_0.03_230)]">© {new Date().getFullYear()}</span>
            </div>
            
            <div className="flex items-center gap-8">
              <a href="#" className="text-sm text-[oklch(0.45_0.03_230)] hover:text-[oklch(0.55_0.12_230)] transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-sm text-[oklch(0.45_0.03_230)] hover:text-[oklch(0.55_0.12_230)] transition-colors">
                Terms
              </a>
              <a href="#" className="text-sm text-[oklch(0.45_0.03_230)] hover:text-[oklch(0.55_0.12_230)] transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
